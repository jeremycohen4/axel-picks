import { verifyLogin, makeSessionToken, SESSION_COOKIE } from "@/lib/auth";

export async function POST(req) {
  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Bad request." }, { status: 400 });
  }

  const found = await verifyLogin(body.username, body.password);
  if (!found) {
    return Response.json(
      { error: "That username and password don't match." },
      { status: 401 }
    );
  }

  const token = await makeSessionToken(found);
  const res = Response.json({ user: found });
  res.headers.set(
    "Set-Cookie",
    `${SESSION_COOKIE}=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${60 * 60 * 24 * 180}`
  );
  return res;
}
