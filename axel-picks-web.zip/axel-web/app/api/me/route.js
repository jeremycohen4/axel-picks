import { cookies } from "next/headers";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/session";

export async function GET() {
  const token = cookies().get(SESSION_COOKIE)?.value;
  const payload = await verifySessionToken(token);
  if (!payload) return Response.json({ user: null }, { status: 401 });
  return Response.json({
    user: { id: payload.id, name: payload.name, color: payload.color },
  });
}
