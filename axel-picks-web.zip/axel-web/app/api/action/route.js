import { getSeason, saveSeason, redactFor, isLocked } from "@/lib/kv";
import { FIXTURES, LOCK_LEAD_MINUTES, fixtureDate } from "@/lib/teams";

function bad(msg, status = 400) {
  return Response.json({ error: msg }, { status });
}

export async function POST(req) {
  const user = JSON.parse(req.headers.get("x-user"));
  let body;
  try {
    body = await req.json();
  } catch {
    return bad("Bad request.");
  }

  let season;
  try {
    season = await getSeason();
  } catch (e) {
    return bad(e.message || "Database not configured.", 500);
  }
  const { type } = body;

  switch (type) {
    case "setPick": {
      const { gw, n, side } = body;
      if (typeof gw !== "number" || typeof n !== "number" || !["H", "A"].includes(side)) {
        return bad("Bad pick.");
      }
      if (isLocked(season, gw)) return bad("This matchweek is locked.", 409);
      if ((season.submitted[user.id] || {})[gw]) {
        return bad("Your picks for this matchweek are saved — edit them first.", 409);
      }
      season.picks[user.id] = season.picks[user.id] || {};
      season.doubles[user.id] = season.doubles[user.id] || {};
      if (season.picks[user.id][n] === side) {
        delete season.picks[user.id][n];
        if (season.doubles[user.id][gw] === n) delete season.doubles[user.id][gw];
      } else {
        season.picks[user.id][n] = side;
      }
      break;
    }

    case "setDouble": {
      const { gw, n } = body;
      if (isLocked(season, gw)) return bad("This matchweek is locked.", 409);
      if ((season.submitted[user.id] || {})[gw]) {
        return bad("Your picks for this matchweek are saved — edit them first.", 409);
      }
      if (!(season.picks[user.id] || {})[n]) return bad("Pick a winner first.");
      season.doubles[user.id] = season.doubles[user.id] || {};
      if (season.doubles[user.id][gw] === n) delete season.doubles[user.id][gw];
      else season.doubles[user.id][gw] = n;
      break;
    }

    case "submit": {
      const { gw } = body;
      if (isLocked(season, gw)) return bad("This matchweek is locked.", 409);
      const games = FIXTURES.filter((f) => f.gw === gw);
      const mine = season.picks[user.id] || {};
      if (!games.every((f) => mine[f.n])) return bad("Pick a winner in every match first.");
      season.submitted[user.id] = season.submitted[user.id] || {};
      season.submitted[user.id][gw] = new Date().toISOString();
      break;
    }

    case "unsubmit": {
      const { gw } = body;
      if (isLocked(season, gw)) return bad("This matchweek is locked.", 409);
      if (season.submitted[user.id]) delete season.submitted[user.id][gw];
      break;
    }

    case "setResult": {
      // Either player may record a result — it's shared, not personal.
      const { n, result } = body;
      if (!Number.isInteger(n)) return bad("Bad match.");
      if (result !== null && !["H", "A", "D"].includes(result)) return bad("Bad result.");
      if (season.results[n] === result) delete season.results[n];
      else if (result) season.results[n] = result;
      else delete season.results[n];
      break;
    }

    case "setLock": {
      const { gw, iso } = body;
      if (iso) season.lockOverrides[gw] = iso;
      else delete season.lockOverrides[gw];
      break;
    }

    case "sync": {
      const { gw } = body;
      const apiKey = process.env.ANTHROPIC_API_KEY;
      if (!apiKey) {
        return bad("Sync isn't set up yet — add ANTHROPIC_API_KEY in Vercel's project settings.", 500);
      }
      const games = FIXTURES.filter((f) => f.gw === gw);
      const list = games
        .map((f) => `${f.n}: ${f.home} vs ${f.away} (on file for ${fixtureDate(f)} ${f.y})`)
        .join("\n");
      const prompt =
        `These are Matchweek ${gw} fixtures from the real English Premier League 2026/27 season:\n${list}\n\n` +
        `For each match, search the web for (a) its actual scheduled kickoff date and time, converted to UTC ` +
        `in ISO 8601, and (b) if it has already been played, the final full-time result.\n\n` +
        `Respond with ONLY compact JSON, no prose, no markdown fences, in exactly this shape:\n` +
        `{"matches":[{"n":<number before the colon above>,"kickoffUTC":<ISO 8601 UTC string or null>,` +
        `"status":"scheduled"|"finished"|"postponed","result":"H"|"A"|"D"|null}]}\n` +
        `H means the first-listed (home) team won, A means the second-listed (away) team won, D is a draw. ` +
        `Use null for anything you can't verify from search results — don't guess.`;

      let resp;
      try {
        resp = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: "claude-sonnet-5",
            max_tokens: 1500,
            messages: [{ role: "user", content: prompt }],
            tools: [{ type: "web_search_20250305", name: "web_search" }],
          }),
        });
      } catch {
        return bad("Couldn't reach the sync service. Try again shortly.", 502);
      }
      if (!resp.ok) {
        const detail = await resp.text().catch(() => "");
        return bad(`Sync request failed (${resp.status}). ${detail.slice(0, 200)}`, 502);
      }

      const data = await resp.json();
      const raw = (data.content || [])
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("\n");
      const jsonStr = (raw.match(/\{[\s\S]*\}/) || [])[0];
      if (!jsonStr) return bad("The sync didn't return usable data. Try again.", 502);

      let parsed;
      try {
        parsed = JSON.parse(jsonStr);
      } catch {
        return bad("The sync response wasn't valid. Try again.", 502);
      }
      const matches = Array.isArray(parsed.matches) ? parsed.matches : [];

      let earliest = null;
      for (const m of matches) {
        const f = games.find((x) => x.n === m.n);
        if (!f) continue;
        if (m.status === "finished" && ["H", "A", "D"].includes(m.result)) {
          season.results[f.n] = m.result;
        }
        if (m.kickoffUTC) {
          const t = new Date(m.kickoffUTC).getTime();
          if (!Number.isNaN(t) && (earliest === null || t < earliest)) earliest = t;
        }
      }
      if (earliest !== null) {
        season.lockOverrides[gw] = new Date(earliest - LOCK_LEAD_MINUTES * 60000).toISOString();
      }
      season.syncedAt = season.syncedAt || {};
      season.syncedAt[gw] = new Date().toISOString();
      break;
    }

    default:
      return bad("Unknown action.");
  }

  await saveSeason(season);
  return Response.json({ season: redactFor(season, user.id) });
}
